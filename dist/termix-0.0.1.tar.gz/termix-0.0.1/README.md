# Welcome to Termix
It's a simple boilerplate for a terminal app.


### Give me some time to add more details
:)


